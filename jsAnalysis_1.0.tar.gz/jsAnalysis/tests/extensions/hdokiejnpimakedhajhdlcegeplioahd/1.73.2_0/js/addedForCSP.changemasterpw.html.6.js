
(function(){ var temp = document.getElementById('masterpassword');
temp.addEventListener('keyup',function(event){update_password_meter(g_username, document.getElementById('masterpassword').value);});

})();
