
(function(){ var temp = document.getElementById('_added_by_transform_2');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Close this window'))});

})();
