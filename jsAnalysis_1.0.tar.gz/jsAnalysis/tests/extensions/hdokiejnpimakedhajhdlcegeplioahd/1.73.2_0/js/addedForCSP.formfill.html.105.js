
(function(){ var temp = document.getElementById('ff_address3');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Your street address'))});

})();
