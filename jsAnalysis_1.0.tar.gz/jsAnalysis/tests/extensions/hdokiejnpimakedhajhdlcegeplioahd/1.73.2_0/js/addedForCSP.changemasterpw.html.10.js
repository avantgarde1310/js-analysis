
(function(){ var temp = document.getElementById('nothanks');
temp.addEventListener('click',function(event){getBG().closecurrenttab('changemasterpw.html'); }});

})();
