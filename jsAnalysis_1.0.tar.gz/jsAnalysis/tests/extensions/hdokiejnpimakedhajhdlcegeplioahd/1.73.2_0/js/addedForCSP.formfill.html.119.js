
(function(){ var temp = document.getElementById('ff_email');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Your email address'))});

})();
