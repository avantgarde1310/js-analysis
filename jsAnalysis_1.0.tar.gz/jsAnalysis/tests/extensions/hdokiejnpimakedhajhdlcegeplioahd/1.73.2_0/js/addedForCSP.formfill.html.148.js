
(function(){ var temp = document.getElementById('ff_nxxmobile');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Middle 3 digits of your phone number'))});
temp.addEventListener('keydown',function(event){onkeydownnxx(this,event);});
temp.addEventListener('keyup',function(event){onkeyupnxx(this,event);});

})();
