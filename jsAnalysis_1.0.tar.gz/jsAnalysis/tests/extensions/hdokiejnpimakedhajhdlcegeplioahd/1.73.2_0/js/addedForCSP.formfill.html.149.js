
(function(){ var temp = document.getElementById('ff_xxxxmobile');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Last 4 digits of your phone number'))});
temp.addEventListener('keydown',function(event){onkeydownxxxx(this,event);});
temp.addEventListener('keyup',function(event){onkeyupxxxx(this,event);});

})();
