
(function(){ var temp = document.getElementById('ff_ccname');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('The full name printed on the credit card'))});

})();
