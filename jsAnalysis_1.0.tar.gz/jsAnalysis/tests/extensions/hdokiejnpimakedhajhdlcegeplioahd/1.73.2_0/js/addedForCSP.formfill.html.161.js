
(function(){ var temp = document.getElementById('ff_ccexp_month');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('The credit card\'s expiration month'))});

})();
