
(function(){ var temp = document.getElementById('ff_county');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Your county name'))});

})();
