
(function(){ var temp = document.getElementById('pff_delete');
temp.addEventListener('click',function(event){return pff_delete()});
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Delete this form fill profile'))});

})();
