
(function(){ var temp = document.getElementById('ff_intnumphone');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Your phone number'))});

})();
