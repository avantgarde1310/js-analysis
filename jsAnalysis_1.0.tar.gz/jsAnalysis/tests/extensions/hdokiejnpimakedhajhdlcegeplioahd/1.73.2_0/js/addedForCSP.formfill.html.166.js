
(function(){ var temp = document.getElementById('ff_ccissuenum');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('The credit card\'s issue number.<br/>Only applicable to certain European brands of debit cards, such as Maestro.'))});

})();
