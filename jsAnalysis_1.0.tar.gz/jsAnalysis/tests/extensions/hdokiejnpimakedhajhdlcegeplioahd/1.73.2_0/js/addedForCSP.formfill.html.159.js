
(function(){ var temp = document.getElementById('ff_ccstart_year');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('The 4 digit year the credit card was issued'))});

})();
