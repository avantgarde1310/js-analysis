
(function(){ var temp = document.getElementById('cancel');
temp.addEventListener('click',function(event){do_close_congratulations();});

})();
