
(function(){ var temp = document.getElementById('cancel');
temp.addEventListener('click',function(event){getBG().closecurrenttab('configure_formfill.html');});

})();
