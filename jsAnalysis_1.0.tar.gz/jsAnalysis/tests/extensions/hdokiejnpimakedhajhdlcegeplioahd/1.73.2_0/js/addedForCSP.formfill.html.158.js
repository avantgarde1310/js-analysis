
(function(){ var temp = document.getElementById('ff_ccstart_month');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('The month the credit card was issued'))});

})();
