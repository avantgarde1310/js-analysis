
(function(){ var temp = document.getElementById('ff_ccexp_year');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('The credit card\'s 4 digit expiration year'))});

})();
