
(function(){ var temp = document.getElementById('createanaccount');
temp.addEventListener('click',function(event){do_submit();});

})();
