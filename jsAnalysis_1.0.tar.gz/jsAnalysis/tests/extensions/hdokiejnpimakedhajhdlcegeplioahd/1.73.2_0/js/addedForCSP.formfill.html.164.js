
(function(){ var temp = document.getElementById('ff_cccsc');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('The credit card\'s security code.<br/>For most credit cards, this is the last 3 digits of a number printed on the back of the card.<br/>For American Express credit cards, it is the last 4 digits of a number printed in small print on the front of the card.'))});

})();
