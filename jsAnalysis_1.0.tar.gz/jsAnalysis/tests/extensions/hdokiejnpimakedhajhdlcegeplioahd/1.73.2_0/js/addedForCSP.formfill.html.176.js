
(function(){ var temp = document.getElementById('ff_notes');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Arbitrary notes to store along with this Form Fill profile'))});

})();
