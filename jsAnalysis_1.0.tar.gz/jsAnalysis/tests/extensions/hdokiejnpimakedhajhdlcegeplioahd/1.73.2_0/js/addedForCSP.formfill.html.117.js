
(function(){ var temp = document.getElementById('ff_timezone');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Your time zone'))});

})();
