
(function(){ var temp = document.getElementById('ff_bankacctnum');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Your bank account number.<br/>This number can typically be found to the right of the routing number on your personal checks.'))});

})();
