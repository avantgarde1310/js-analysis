
(function(){ var temp = document.getElementById('changeyourpassword');
temp.addEventListener('click',function(event){do_submit();});

})();
