
(function(){ var temp = document.getElementById('continue');
temp.addEventListener('click',function(event){do_close_congratulations();});

})();
