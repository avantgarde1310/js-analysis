
(function(){ var temp = document.getElementById('ff_bankroutingnum');
temp.addEventListener('mouseout',function(event){ttoff()});
temp.addEventListener('mouseover',function(event){ttabove(this,gt('Your bank\'s routing number.<br/>This 9 digit number can typically be found on your personal checks in the bottom left corner.'))});

})();
