
      $(function() {
        if (navigator.language.substring(0, 2) != "en")
          $("#translation_credits").show();
      });
    