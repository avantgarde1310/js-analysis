
          $(function() {
            $("#last-step").load("http://chromeadblock.com/donate/install/index.php", $.param(QPS));
          });
        