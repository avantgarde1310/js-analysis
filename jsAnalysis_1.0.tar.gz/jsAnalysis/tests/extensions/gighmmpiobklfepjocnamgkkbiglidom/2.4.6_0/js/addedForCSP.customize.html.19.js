
        // Chrome puts link in button; Safari puts it here.
        $(function() { $("#adreportarea").toggle(SAFARI); });
      