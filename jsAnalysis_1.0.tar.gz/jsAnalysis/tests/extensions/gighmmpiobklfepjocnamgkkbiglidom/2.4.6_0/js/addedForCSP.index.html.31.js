
          $(function() {
            $("#cleaner-warning a").click(function() {
              alert(translate("filecleanerwarning"));
            });
          });
        