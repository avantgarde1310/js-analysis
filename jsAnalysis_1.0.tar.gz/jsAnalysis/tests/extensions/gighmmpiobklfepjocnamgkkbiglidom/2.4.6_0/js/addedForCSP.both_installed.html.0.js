
      $(function() {
        localizePage();
      });
    