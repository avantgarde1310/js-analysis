
        $("#enable_show_advanced_options").change(function() {
          window.setTimeout(function() {
            // To show or hide the advanced options on the options page
            window.location.reload();
          }, 50);
        });
      