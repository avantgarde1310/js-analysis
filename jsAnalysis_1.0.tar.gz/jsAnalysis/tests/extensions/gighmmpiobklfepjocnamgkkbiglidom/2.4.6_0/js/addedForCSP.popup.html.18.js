
        $(function() {
          localizePage();
        });
      