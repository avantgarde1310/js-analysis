
(function(){ var temp = document.getElementById('_added_by_transform_1');
temp.addEventListener('click',function(event){save_options()});

})();
