
      function toggle(id) {
        var style = document.getElementById(id).style;
        style.display = style.display ? '' : 'none';
      }
    