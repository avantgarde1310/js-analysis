
        if (navigator.platform.toLowerCase().indexOf('win') != 0) {
          document.getElementById('nonWinWarning').style.display = '';
        }
      