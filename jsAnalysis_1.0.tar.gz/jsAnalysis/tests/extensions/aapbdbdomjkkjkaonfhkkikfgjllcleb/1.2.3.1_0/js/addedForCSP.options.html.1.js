
(function(){ var temp = document.getElementById('_added_by_transform_0');
temp.addEventListener('load',function(event){new OptionsControl().init()});

})();
