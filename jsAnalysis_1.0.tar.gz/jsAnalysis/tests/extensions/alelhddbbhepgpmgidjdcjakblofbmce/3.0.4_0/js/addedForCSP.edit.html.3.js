
(function(){ var temp = document.getElementById('_added_by_transform_3');
temp.addEventListener('click',function(event){$('#saveOptionContent>.diigo').removeClass('signin');});

})();
