a = chrome;
b = a.tabs;
c = a.tabs.getCurrent;
d = a;
c();
e();

function e(abc, def){
    c();
    return abc + def;
}
