a = chrome;
b = a.tabs;
f = a["tabs"];
c = a.tabs.getCurrent;
d = a;
c();
e();

